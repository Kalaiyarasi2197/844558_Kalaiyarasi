$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/main/resources/feature/Taskmanagement.Feature");
formatter.feature({
  "line": 2,
  "name": "Task_Management Website",
  "description": "",
  "id": "task-management-website",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@Task_Management"
    }
  ]
});
formatter.scenario({
  "line": 5,
  "name": "",
  "description": "Add/Edit Task in TaskMangement Website",
  "id": "task-management-website;",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 4,
      "name": "@TC_01_Edit"
    }
  ]
});
formatter.step({
  "line": 7,
  "name": "The user launch the Chrome application",
  "keyword": "Given "
});
formatter.step({
  "line": 8,
  "name": "Click first task from the tasks list",
  "keyword": "When "
});
formatter.step({
  "line": 9,
  "name": "Edit name field from Add/Edit task",
  "keyword": "Then "
});
formatter.step({
  "line": 10,
  "name": "Click on submit Button to update task",
  "keyword": "And "
});
formatter.match({
  "location": "EditTaskStep.the_user_launch_chrome_edit()"
});
});